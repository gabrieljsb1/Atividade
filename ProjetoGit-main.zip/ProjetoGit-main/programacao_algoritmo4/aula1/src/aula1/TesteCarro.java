package aula1;

public class TesteCarro {

	public static void main(String[] args) {
		
		Carro c1 = new Carro();
		
		c1.nome="Ferrari";
		c1.marca="Fiat";
		c1.ano=2026;
		c1.vel=60;
		
		c1.acelerar(10);
		System.out.println("Velocidade: "+ c1.vel + "km/h");
		
		c1.reduzir(30);
		System.out.println("Velocidade: " + c1.vel + "km/h");

	}

}
