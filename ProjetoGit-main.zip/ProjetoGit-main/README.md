# Projeto Inicial GitHub

Olá, esse projeto ensina você a usar o git.
Isso é uma alteração.

## Atualizações

* nova pasta ebook com projetos das aulas de julho e agosto

## Informações das atividades

As atividades foram realizados com o propósito de aprendermos um pouco mais sobre o funcionamento e estruturas de uma classe:  atributos, construtores privados e públicos e como declará-los da maneira correta.

## Data de realização das atividade

29/07 a 31/07 - aula 1
* `Carro.java` e `TesteCarro.java`

05/08 - poo
* `Carro.java` e `TestarCarro.java`

12/08 - poo
* `Produto.java` e `ProdutoTestar.java`

19/08 - exemplo3
* `Carro.java` e `TestarCarro.java`, `Aluno.java` e `AlunoTestar.java`

## Passo a Passo para a conclusão dessa tarefa.

* Baixei os arquivos do ebook salvos no Google Drive.
* Conferi as datas de cada atividade por um documento entregue como tarefa.
* Movi a pasta das atividades para o diretório do repósitorio GitHub
* Realizei os seguintes comandos:

* `git checkout -b programacao_algoritmo` --> para criar um novo branch
* `git add programacao_algoritmo4` --> copiar a pasta para o envio
* `git commit -m "ebook dos projetos de julho e agosto"` --> comitar com os detalhes da pasta
* `git push -u origin programacao_algoritmo` --> enviar o commit para o GitHub
* `git checkout main` --> voltar para a branch `main`
* `git merge programacao_algoritmo` --> mesclar as duas branchs
* `git push origin main` --> enviar as alterações
